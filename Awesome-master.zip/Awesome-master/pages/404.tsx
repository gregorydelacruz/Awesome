import { NotFound } from "@/components/common/not-found";
import { Layout } from "@/components/layout";

const NotFoundPage = () => {
  return <NotFound />;
};

export default NotFoundPage;
